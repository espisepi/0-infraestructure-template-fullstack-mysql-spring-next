package com.sepinaco.templatebackendspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemplateBackendSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
