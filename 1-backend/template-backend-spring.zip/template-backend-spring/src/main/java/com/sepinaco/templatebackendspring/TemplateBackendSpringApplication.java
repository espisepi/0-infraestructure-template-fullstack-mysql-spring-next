package com.sepinaco.templatebackendspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateBackendSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateBackendSpringApplication.class, args);
	}

}
